//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company�s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.       
// *******************************************************************
// PICkit 2 PIC18F4520 Lesson 8 - Interrupts
//
// This lesson goes over using interrupts to process external and 
// peripheral events.  The switch activates external interrupt INT0
// when pressed, and Timer0 is now serviced in an interrupt when it
// overflows.  Functionally, the program works the same as lesson 07.
//
// *******************************************************************
// *    See included documentation for Lesson instructions           *
// *******************************************************************

/** C O N F I G U R A T I O N   B I T S ******************************/

#pragma config FOSC = INTIO67, FCMEN = OFF, IESO = OFF                       // CONFIG1H
#pragma config PWRT = OFF, BOREN = SBORDIS, BORV = 30                        // CONFIG2L
#pragma config WDTEN = OFF, WDTPS = 32768                                     // CONFIG2H
#pragma config MCLRE = ON, LPT1OSC = OFF, PBADEN = ON, CCP2MX = PORTC       // CONFIG3H
#pragma config STVREN = ON, LVP = OFF, XINST = OFF                          // CONFIG4L
#pragma config CP0 = OFF, CP1 = OFF, CP2 = OFF, CP3 = OFF                   // CONFIG5L
#pragma config CPB = OFF, CPD = OFF                                         // CONFIG5H
#pragma config WRT0 = OFF, WRT1 = OFF, WRT2 = OFF, WRT3 = OFF               // CONFIG6L
#pragma config WRTB = OFF, WRTC = OFF, WRTD = OFF                           // CONFIG6H
#pragma config EBTR0 = OFF, EBTR1 = OFF, EBTR2 = OFF, EBTR3 = OFF           // CONFIG7L
#pragma config EBTRB = OFF                                                  // CONFIG7H


/** P R O T O T Y P E S ******************************************************/

/** I N C L U D E S **************************************************/
#include "p18f46k20.h"
#include <stdio.h> 
#include <stdlib.h>
#include <spi.h>
#include <usart.h>
#include <math.h>
/** I N T E R R U P T S ***********************************************/

//----------------------------------------------------------------------------

/** D E C L A R A T I O N S *******************************************/
void DAC_SPI_send(unsigned char MSB,unsigned char LSB);

void main (void)
{
	unsigned char LSB=0,MSB=0;
	int dataX=0,dataY=0,dataZ=0;
	OSCCON = 0b01110000;
	TRISD=0x00;
	TRISBbits.RB0=0;
	TRISCbits.RC5=0;
	TRISCbits.RC4=1;
	TRISCbits.RC3=0;
    MSB=0b01110000;

	OpenSPI(SPI_FOSC_4, MODE_00, SMPMID); //open SPI

	while (1)
	{
		
		
		
		if (LSB>252)
			{
				LSB=0b00000111;
				MSB++;
			}
		if ((MSB>0b01111111))
			{
			LSB=0b00000111;
			MSB=0b01110000;
			}
		DAC_SPI_send(MSB,LSB);
		LSB=LSB+0b00011111;
	}



}



void DAC_SPI_send(unsigned char MSB,unsigned char LSB)
{

PORTBbits.RB0=0;//ENABLE master to communicate with slave
WriteSPI(MSB); //
while(!DataRdySPI());
WriteSPI(LSB);
while(!DataRdySPI());
PORTBbits.RB0=1;

}

