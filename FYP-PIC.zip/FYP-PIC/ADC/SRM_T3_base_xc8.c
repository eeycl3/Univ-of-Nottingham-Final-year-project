//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company�s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.       
// *******************************************************************
// PICkit 2 PIC18F4520 Lesson 8 - Interrupts
//
// This lesson goes over using interrupts to process external and 
// peripheral events.  The switch activates external interrupt INT0
// when pressed, and Timer0 is now serviced in an interrupt when it
// overflows.  Functionally, the program works the same as lesson 07.
//
// *******************************************************************
// *    See included documentation for Lesson instructions           *
// *******************************************************************

/** C O N F I G U R A T I O N   B I T S ******************************/

#pragma config FOSC = INTIO67, FCMEN = OFF, IESO = OFF                       // CONFIG1H
#pragma config PWRT = OFF, BOREN = SBORDIS, BORV = 30                        // CONFIG2L
#pragma config WDTEN = OFF, WDTPS = 32768                                     // CONFIG2H
#pragma config MCLRE = ON, LPT1OSC = OFF, PBADEN = ON, CCP2MX = PORTC       // CONFIG3H
#pragma config STVREN = ON, LVP = OFF, XINST = OFF                          // CONFIG4L
#pragma config CP0 = OFF, CP1 = OFF, CP2 = OFF, CP3 = OFF                   // CONFIG5L
#pragma config CPB = OFF, CPD = OFF                                         // CONFIG5H
#pragma config WRT0 = OFF, WRT1 = OFF, WRT2 = OFF, WRT3 = OFF               // CONFIG6L
#pragma config WRTB = OFF, WRTC = OFF, WRTD = OFF                           // CONFIG6H
#pragma config EBTR0 = OFF, EBTR1 = OFF, EBTR2 = OFF, EBTR3 = OFF           // CONFIG7L
#pragma config EBTRB = OFF                                                  // CONFIG7H


/** P R O T O T Y P E S ******************************************************/

/** I N C L U D E S **************************************************/
#include "p18f46k20.h"
#include <stdio.h> 
#include <stdlib.h>
#include <spi.h>
#include <usart.h>

/** I N T E R R U P T S ***********************************************/

//----------------------------------------------------------------------------

/** D E C L A R A T I O N S *******************************************/

unsigned int SPI_getADC(void);
void USARTWriteByte(char ch);
void USARTWriteString(const char *str);
void USARTWriteInt(int val,unsigned char field_length);
void main (void)
{
	unsigned int data;
	OSCCON = 0b01100000;
	TRISD=0x00;
	TRISBbits.RB0=0;
	TRISCbits.RC5=0;
	TRISCbits.RC4=1;
	TRISCbits.RC3=0;
	TRISCbits.RC6=0;
	TRISCbits.RC7=1;
OpenSPI(SPI_FOSC_4, MODE_00, SMPMID); 


	
OpenUSART( USART_TX_INT_OFF & USART_RX_INT_OFF  & USART_ASYNCH_MODE & USART_EIGHT_BIT  & USART_CONT_RX &USART_BRGH_HIGH,12);
	while (1)
	{	
		LATD=0xf0;
		data=SPI_getADC();
		data=(int)(1.0*data*0.0625);
		USARTWriteInt(data,4);
		//USARTWriteInt(11,2);
		USARTWriteByte('\r');


}
}



unsigned int SPI_getADC(void)
{ 
unsigned int x3,x2,x1=0;
unsigned int x;
  PORTBbits.RB0 = 0;
	x3=ReadSPI();
	x2=ReadSPI();
	x1=ReadSPI();
 	PORTBbits.RB0 = 1;
	x1=(x1>>2)&0b00111111;
	x=(x3<<14)+(x2<<6)+x1;
    return (x);
}

void USARTWriteByte(char ch)
{
	//Wait for TXREG Buffer to become available
	while(!TXIF);

	//Write data
	TXREG=ch;
}

void USARTWriteString(const char *str)
{
	while((*str)!='\0')
	{
		//Wait for TXREG Buffer to become available
		while(!TXIF);

		//Write data
		TXREG=(*str);

		//Next goto char
		str++;
	}
}
void USARTWriteInt(int val,unsigned char field_length)
{
	if(val<0) 
	{
		USARTWriteByte('-');	//Write '-' sign for negative numbers.
		val=(val*(-1));				//Make it positive.
	}

	//Convert Number To String and pump over Tx Channel.
	char str[5]={0,0,0,0,0};
	int i=4,j=0;
	while(val)
	{
		str[i]=val%10;
		val=val/10;
		i--;
	}
	if(field_length>5)
		while(str[j]==0) j++;
	else
		j=5-field_length;
	
	for(i=j;i<5;i++)
	{
		USARTWriteByte('0'+str[i]);
	}
}