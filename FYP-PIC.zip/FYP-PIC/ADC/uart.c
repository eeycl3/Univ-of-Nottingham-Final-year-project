

#include <htc.h>

#include "uart.h"

void USARTWriteByte(char ch)
{
	//Wait for TXREG Buffer to become available
	while(!TXIF);

	//Write data
	TXREG=ch;
}

void USARTWriteString(const char *str)
{
	while((*str)!='\0')
	{
		//Wait for TXREG Buffer to become available
		while(!TXIF);

		//Write data
		TXREG=(*str);

		//Next goto char
		str++;
	}
}

/*

Writes a line of text to USART and goes to new line
The new line is Windows style CR/LF pair.

This will work on Hyper Terminal Only NOT on Linux

*/

void USARTWriteLine(const char *ln)
{
	USARTWriteString(ln);
	USARTWriteString("\r\n");
}

void USARTWriteInt(int val,unsigned char field_length)
{
	if(val<0) 
	{
		USARTWriteByte('-');	//Write '-' sign for negative numbers.
		val=(val*(-1));				//Make it positive.
	}

	//Convert Number To String and pump over Tx Channel.
	char str[5]={0,0,0,0,0};
	int i=4,j=0;
	while(val)
	{
		str[i]=val%10;
		val=val/10;
		i--;
	}
	if(field_length>5)
		while(str[j]==0) j++;
	else
		j=5-field_length;
	
	for(i=j;i<5;i++)
	{
		USARTWriteByte('0'+str[i]);
	}
}


unsigned char USARTReadByte()
{
	while(!RCIF);	//Wait for a byte
	
	return RCREG;
}
