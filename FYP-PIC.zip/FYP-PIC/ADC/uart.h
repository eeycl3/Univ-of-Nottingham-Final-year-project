
#include <htc.h>

void USARTWriteByte(char);

void USARTWriteString(const char *);

void USARTWriteLine(const char *);

void USARTWriteInt(int ,unsigned char);

unsigned char USARTReadByte();
