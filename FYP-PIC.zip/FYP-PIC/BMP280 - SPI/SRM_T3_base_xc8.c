//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company�s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.       
// *******************************************************************
// PICkit 2 PIC18F4520 Lesson 8 - Interrupts
//
// This lesson goes over using interrupts to process external and 
// peripheral events.  The switch activates external interrupt INT0
// when pressed, and Timer0 is now serviced in an interrupt when it
// overflows.  Functionally, the program works the same as lesson 07.
//
// *******************************************************************
// *    See included documentation for Lesson instructions           *
// *******************************************************************

/** C O N F I G U R A T I O N   B I T S ******************************/

#pragma config FOSC = INTIO67, FCMEN = OFF, IESO = OFF                       // CONFIG1H
#pragma config PWRT = OFF, BOREN = SBORDIS, BORV = 30                        // CONFIG2L
#pragma config WDTEN = OFF, WDTPS = 32768                                     // CONFIG2H
#pragma config MCLRE = ON, LPT1OSC = OFF, PBADEN = ON, CCP2MX = PORTC       // CONFIG3H
#pragma config STVREN = ON, LVP = OFF, XINST = OFF                          // CONFIG4L
#pragma config CP0 = OFF, CP1 = OFF, CP2 = OFF, CP3 = OFF                   // CONFIG5L
#pragma config CPB = OFF, CPD = OFF                                         // CONFIG5H
#pragma config WRT0 = OFF, WRT1 = OFF, WRT2 = OFF, WRT3 = OFF               // CONFIG6L
#pragma config WRTB = OFF, WRTC = OFF, WRTD = OFF                           // CONFIG6H
#pragma config EBTR0 = OFF, EBTR1 = OFF, EBTR2 = OFF, EBTR3 = OFF           // CONFIG7L
#pragma config EBTRB = OFF                                                  // CONFIG7H


/** P R O T O T Y P E S ******************************************************/

/** I N C L U D E S **************************************************/
#include "p18f46k20.h"
#include <stdio.h> 
#include <stdlib.h>
#include <spi.h>
#include <usart.h>
#include <math.h>
#define BMP280_U32_t unsigned long
#define BMP280_S32_t signed long
#define uint16_t  unsigned int
#define int16_t		signed int
#define BME280_U32_t unsigned long
#define BME280_S32_t signed long

/** I N T E R R U P T S ***********************************************/

//----------------------------------------------------------------------------

/** D E C L A R A T I O N S *******************************************/

void USARTWriteLine(const char *ln);
void USARTWriteString(const char *str);
void USARTWriteByte(char ch);
void USARTWriteInt(long val,unsigned char field_length);
void BMP_SPI_send(unsigned char addr,unsigned char data);
unsigned int BMP_SPI_get(unsigned char addr);
BMP280_S32_t t_fine,temp,pressure;
BMP280_U32_t  bmp280_compensate_P_int32(BMP280_S32_t adc_P);
BMP280_S32_t  bmp280_compensate_T_int32(BMP280_S32_t adc_T);
BMP280_U32_t BME280_compensate_H_int32(BMP280_S32_t adc_H);
void main (void)
{

BMP280_S32_t hum=0,temp=0,pressure=0;

	OSCCON = 0b01100000;
	TRISD=0x00;
	TRISBbits.RB0=0;
	TRISCbits.RC5=0;
	TRISCbits.RC4=1;
	TRISCbits.RC3=0;
	
	
	OpenSPI(SPI_FOSC_4, MODE_00, SMPMID); //open SPI
	OpenUSART( USART_TX_INT_OFF  &
            USART_RX_INT_OFF  &
            USART_ASYNCH_MODE &
            USART_EIGHT_BIT   &
            USART_CONT_RX     &
            USART_BRGH_HIGH,
            12             );
		CloseSPI();
		BMP_SPI_send(0xE0,0xB6);
		BMP_SPI_send(0xF4,0xFE);

		USARTWriteInt(222222,6);
		USARTWriteByte('\r');
		USARTWriteByte(0x4C);
		USARTWriteByte('\r');
		USARTWriteString("PIC UART TEST! ");

	while (1)
	{

		LATD=0xFF;
    	 BMP_SPI_send(0xF2,0xFF);//Humidtiy
    	 BMP_SPI_send(0xF4,0xFE);//Forced moudle. Weather application
	
    	hum=BMP_SPI_get(0xFD);
    	hum=hum<<8;
    	hum=hum+(BMP_SPI_get(0xFE));
		temp=(BMP_SPI_get(0xFA)<<8)|(BMP_SPI_get(0xFB));
		temp=((temp<<4)|(BMP_SPI_get(0xFC)>>4));
		pressure=BMP_SPI_get(0xF7);
    	pressure=pressure<<8;
   		pressure=pressure+BMP_SPI_get(0xF8);
    	pressure<<=8;
    	pressure|=BMP_SPI_get(0xF9);
    	pressure>>=4;
		long a=(bmp280_compensate_P_int32(pressure));
	    long b=(bmp280_compensate_T_int32(temp))/100;
		long c=BME280_compensate_H_int32(hum)/1024;
				USARTWriteString("Temp:");
		USARTWriteInt(b,2);
		USARTWriteByte(' ');
		USARTWriteString("\r");
				USARTWriteString("Pressure:");
		USARTWriteInt(a,6);
		USARTWriteByte(' ');
		USARTWriteString("\r");
				USARTWriteString("HUM:");
		USARTWriteInt(c,2);
		USARTWriteByte(' ');
		USARTWriteString("\r");	
				USARTWriteString("  ");
	USARTWriteString("\r");
		Delay10KTCYx(20);

	
		

	}
}
void USARTWriteByte(char ch)
{
	//Wait for TXREG Buffer to become available
	while(!TXIF);

	//Write data
	TXREG=ch;
}

void USARTWriteString(const char *str)
{
	while((*str)!='\0')
	{
		//Wait for TXREG Buffer to become available
		while(!TXIF);

		//Write data
		TXREG=(*str);

		//Next goto char
		str++;
	}
}

void USARTWriteLine(const char *ln)
{
	USARTWriteString(ln);
	USARTWriteString("\r\n");
}

void USARTWriteInt(long val,unsigned char field_length)
{
	if(val<0) 
	{
		USARTWriteByte('-');	//Write '-' sign for negative numbers.
		val=(val*(-1));				//Make it positive.
	}

	//Convert Number To String and pump over Tx Channel.
	char str[6]={0,0,0,0,0,0};
	int i=5,j=0;
	while(val)
	{
		str[i]=val%10;
		val=val/10;
		i--;
	}
	if(field_length>6)
		while(str[j]==0) j++;
	else
		j=6-field_length;
	
	for(i=j;i<6;i++)
	{
		USARTWriteByte('0'+str[i]);
	}
}


unsigned int BMP_SPI_get(unsigned char addr)
{ 

unsigned int x=0;
	OpenSPI(SPI_FOSC_4, MODE_00, SMPMID);
  PORTBbits.RB0 = 0;
  WriteSPI(addr);
	x=ReadSPI();
 PORTBbits.RB0 = 1;
 	CloseSPI();
    return (x);
}

void BMP_SPI_send(unsigned char addr,unsigned char data)
{
OpenSPI(SPI_FOSC_4, MODE_00, SMPMID);
addr=addr-0b10000000;
PORTBbits.RB0=0;//ENABLE master to communicate with slave
WriteSPI(addr);

WriteSPI(data);

PORTBbits.RB0=1;
CloseSPI();
}

BMP280_S32_t bmp280_compensate_T_int32(BMP280_S32_t adc_T)
{BMP280_S32_t var1, var2, T;
	 uint16_t dig_T1;
     int16_t  dig_T2;
     int16_t  dig_T3;
dig_T1=(unsigned int)((BMP_SPI_get(0x89)<<8)|(BMP_SPI_get(0x88)));
		dig_T2=(int)((BMP_SPI_get(0x8B)<<8)|(BMP_SPI_get(0x8A)));
		dig_T3=(int)((BMP_SPI_get(0x8D)<<8)|(BMP_SPI_get(0x8C)));
var1 = ((((adc_T>>3)- ((BMP280_S32_t)dig_T1<<1))) * ((BMP280_S32_t)dig_T2)) >> 11;
var2 = (((((adc_T>>4)-((BMP280_S32_t)dig_T1)) * ((adc_T>>4)-((BMP280_S32_t)dig_T1))) >>12)*((BMP280_S32_t)dig_T3)) >> 14;
t_fine = var1 + var2;
T = (t_fine * 5 + 128) >> 8;
return T;
}
BMP280_U32_t  bmp280_compensate_P_int32(BMP280_S32_t adc_P)
{
BMP280_S32_t var1, var2;
BMP280_U32_t p;
      uint16_t dig_P1;
      int16_t  dig_P2;
      int16_t  dig_P3;
      int16_t  dig_P4;
      int16_t  dig_P5;
      int16_t  dig_P6;
      int16_t  dig_P7;
      int16_t  dig_P8;
      int16_t  dig_P9;
    dig_P1=(unsigned int)((BMP_SPI_get(0x8F)<<8)|(BMP_SPI_get(0x8E)));
    dig_P2=(int)((BMP_SPI_get(0x91)<<8)|(BMP_SPI_get(0x90)));
    dig_P3=(int)((BMP_SPI_get(0x93)<<8)|(BMP_SPI_get(0x92)));
    dig_P4=(int)((BMP_SPI_get(0x95)<<8)|(BMP_SPI_get(0x94)));
    dig_P5=(int)((BMP_SPI_get(0x97)<<8)|(BMP_SPI_get(0x96)));
    dig_P6=(int)((BMP_SPI_get(0x99)<<8)|(BMP_SPI_get(0x98)));
    dig_P7=(int)((BMP_SPI_get(0x9B)<<8)|(BMP_SPI_get(0x9A)));
    dig_P8=(int)((BMP_SPI_get(0x9D)<<8)|(BMP_SPI_get(0x9C)));
    dig_P9=(int)((BMP_SPI_get(0x9F)<<8)|(BMP_SPI_get(0x9E)));
var1 = (((BMP280_S32_t)t_fine)>>1) - (BMP280_S32_t)64000;
var2 = (((var1>>2) * (var1>>2)) >> 11 ) * ((BMP280_S32_t)dig_P6);
var2 = var2 + ((var1*((BMP280_S32_t)dig_P5))<<1);
var2 = (var2>>2)+(((BMP280_S32_t)dig_P4)<<16);
var1 = (((dig_P3 * (((var1>>2) * (var1>>2)) >> 13 )) >> 3) + ((((BMP280_S32_t)dig_P2) * var1)>>1))>>18;
var1 =((((32768+var1))*((BMP280_S32_t)dig_P1))>>15);
if (var1 == 0)
{
return 0; // avoid exception caused by division by zero
}
p = (((BMP280_U32_t)(((BMP280_S32_t)1048576)-adc_P)-(var2>>12)))*3125;
if (p < 0x80000000)
{
p = (p << 1) / ((BMP280_U32_t)var1);
}
else
{
p = (p / (BMP280_U32_t)var1) * 2;
}
var1 = (((BMP280_S32_t)dig_P9) * ((BMP280_S32_t)(((p>>3) * (p>>3))>>13)))>>12;
var2 = (((BMP280_S32_t)(p>>2)) * ((BMP280_S32_t)dig_P8))>>13;
p = (BMP280_U32_t)((BMP280_S32_t)p + ((var1 + var2 + dig_P7) >> 4));
return p;
}

BMP280_U32_t BME280_compensate_H_int32(BMP280_S32_t adc_H)
{
BMP280_S32_t v_x1_u32r;
unsigned char dig_H1,dig_H3;
signed int dig_H2,dig_H4,dig_H5;
signed char dig_H6;
dig_H1=(unsigned char)(BMP_SPI_get(0xA1));
dig_H2=(signed int)((BMP_SPI_get(0xE2)<<8)|(BMP_SPI_get(0xE1)));
dig_H3=(unsigned char)(BMP_SPI_get(0xE3));
dig_H4=(signed int)((BMP_SPI_get(0xE4)<<4)|(BMP_SPI_get(0xE5)&0b00001111));
dig_H5=(signed int)((BMP_SPI_get(0xE6)<<4)|((BMP_SPI_get(0xE5)&0b11110000)>>4));
dig_H6=(unsigned char)(BMP_SPI_get(0xE7));
v_x1_u32r = (t_fine - ((BME280_S32_t)76800));
v_x1_u32r = (((((adc_H << 14) - (((BME280_S32_t)dig_H4) << 20) -(((BME280_S32_t)dig_H5) * v_x1_u32r)) +((BME280_S32_t)16384)) >> 15) * (((((((v_x1_u32r * ((BME280_S32_t)dig_H6)) >> 10) * (((v_x1_u32r *((BME280_S32_t)dig_H3)) >> 11) + ((BME280_S32_t)32768))) >> 10) + ((BME280_S32_t)2097152)) *((BME280_S32_t)dig_H2) + 8192) >> 14));
v_x1_u32r = (v_x1_u32r - (((((v_x1_u32r >> 15) * (v_x1_u32r >> 15)) >> 7) * ((BME280_S32_t)dig_H1)) >> 4));
v_x1_u32r = (v_x1_u32r < 0 ? 0 : v_x1_u32r);
v_x1_u32r = (v_x1_u32r > 419430400 ? 419430400 : v_x1_u32r);
return (BME280_U32_t)(v_x1_u32r>>12);
}